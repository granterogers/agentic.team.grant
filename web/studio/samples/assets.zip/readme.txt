The course artwork, as delivered by the designer.
